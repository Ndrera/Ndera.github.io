<?php
if(isset($_POST['submit']))
{
	   if($_POST['name'] && $_POST['msg'])
	   {
		   $msg='Name:'.$_POST['name']."\n"  
	        .'Email:'.$_POST['email']."\n"
	        .'Comment:'.$_POST['msg'];
			mail('s.madela@gmail.com','Contact Us Form Feedback', $msg);
			$display="Feedback Sent Successfully";
	   }
	   else
	   {
		   $display="Fields needed!!!";
	   }
	  
	   
}
  


?>
<!Doctype html>
<html lang="en">
  <head>
    <title>Contact Page</title>
	<link rel="stylesheet" href="css/style.css">
	<script type="text/javascript" language="javascript" src="js/validation.js">
	   </script>
  
  </head>
  <body>
     <div class="container">
	  
		<!--Header-->
		<header>
		  <h1 style="font-family:Agency FB;font-size:60px; color:white;">Contact Page</h1>
		</header>
		<!--Navigation--->
		
		<nav>
		</nav>
		<!--Content-->
		<Content>
		
		    <center >
			        <form method="post" action="" onsubmit="var tmp= ValName();ValEmail(); ValText();return tmp;">
					
			            <table style="background-color:#808080; padding:10px; border:4px solid gold;">
						    <tr  class="para">
                                 <td></td>
                                 <td valign="top">
                                 <strong>Contacts :</strong>
                                 <br>
                                 <br>
                                  Postal Address<br><br>
                                 <img src="images/1.jpg" width="166" height="114" >
                                 </td>
								 
                                 <td valign="bottom">
                                 <!--<strong >Sizwe.</strong><br>-->
                                   NO.46 Nelson Street<br>
                                   Sothdale<br> 2091<br>
                                   Cell:        076 442 6168<br>
                                   <br>
                                   E-mail:   <a href="mailto:nderasm@gmail.com" class="link_color">nderasm@gmail.com</a>
                                   <br>
      
                                  </td>
								  <td><br><br><br></td>
                            </tr>
 
                                <td></td>
                                <!--<td><img src="images/l3.jpg" height="4" width="200%"/></p></td>-->
                                 <td><p><hr width="150%" /></p></td>
                            </tr>
	                        
							
							
						  <tr class="para">
                             <td></td>
                             <td><p><strong>Contact Form :</strong></p></td>
                           </tr>
     
                           <tr>
                              <td></td> 
                              <td width="300"><input name="name" type="text" class="input col6" id="names" value="&nbsp;Name:"><br>
							        <label  id="lbname"></label>
							  <br>
                              <input name="email" type="text" class="input col6" id="email" value="&nbsp;E-mail:"><br>
							  <label  id="lbemail"></label>
							  <br>
                              

                             <!-- <a href="mailto:s.madela@gmail.com" class="read">send</a></td>-->
                            </td>
                              <td valign="top"><textarea name="msg" id="text">&nbsp;Message:</textarea><br>
							  <label  id="lbtext"></label>
							  <br>
							  
							  <input type="submit" name="submit" value="Submit" >
							  </td>
							  
							   
                          </tr>
  
  
                      </tr>
 
                         <td></td>
                        <!-- <td><p><img src="images/l3.jpg" height="4" width="100%"/></p></td>-->
                           <!--<td><hr width="200" /></td>-->
                          </tr>
						</table>
					   </form>
					 </center>
		
		</Content>
		 <div class="clear"></div>
		<!--Footer-->
		<footer>
		</footer>
	 </div>
  </body>
</html>