﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Test
{
    public partial class frmMain : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=SIZWE;Initial Catalog=Login;Integrated Security=True");
        public frmMain(string msg)
        {
            InitializeComponent();
            labelHelloWorld.Text = msg;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            if (labelHelloWorld.Text == "Admin")
            {
                //ADMIN    user1=ADMIN
                //MessageBox.Show("Its user 1 bby");
                //labelHelloWorld.Text = " ";
                lblHello.Visible = false;
            }
            else
            {
                //User   user2= USER
                //labelHelloWorld.Text = "Hello World ";
                lblHello.Text = "Hello World!!";
                //btnAddUser.Enabled = false;
                btnAddUser.Visible = false;
                textBoxAddUsername.Visible = false;
                textBoxAddPassword.Visible = false;
                label1.Visible = false;
                label2.Visible = false;
                label4.Visible = false;
                //label3.Visible = false;

            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            string query = "Select * from table_Login Where username='" + textBoxAddUsername.Text.Trim() + "' AND password='" + textBoxAddPassword.Text.Trim() + "'";
            //string query = "Select Role from table_Login Where username='" + txtUsername.Text.Trim() + "' AND password='" + txtPassword.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);

                        if (dtbl.Rows.Count == 1)
                        {
                            MessageBox.Show("Sorry, this user already exist in our system records, Please try another one.");
                        }
                        else
                        {
                            string role = "User";

                            con.Open();
                            SqlCommand cmd = con.CreateCommand();
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandText = "Insert into table_Login values('" + textBoxAddUsername.Text + "','" + textBoxAddPassword.Text + "','" + role + "')";
                            cmd.ExecuteNonQuery();
                            con.Close();

                            MessageBox.Show("Record inserted successfully");
                        }

         
            
           
        }

        private void btnAddExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
