﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Test
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=SIZWE;Initial Catalog=Login;Integrated Security=True");
           // string query = "Select * from table_Login Where username='" + txtUsername.Text.Trim() + "' AND password='" + txtPassword.Text.Trim() + "'";
            string query = "Select Role from table_Login Where username='" + txtUsername.Text.Trim() + "' AND password='" + txtPassword.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                frmMain objFrmMain = new frmMain(dtbl.Rows[0]["Role"].ToString());
                this.Hide();
                objFrmMain.Show();

               /* if (dtbl.Rows[0]["Role"].ToString() == "Admin")
                {
                    //MessageBox.Show("Madela you didiit, glory be to the most high god, Jehova");
                    //frmMain objFrmMain = new frmMain("Hello World");
                    frmMain objFrmMain = new frmMain(dtbl.Rows[0]["Role"].ToString());
                    this.Hide();
                    objFrmMain.Show();
                }
                else if (dtbl.Rows[0]["Role"].ToString() == "User")
                {
                    // MessageBox.Show("User 2 , glory be to the most high god, Jehova");
                    frmMain objFrmMain = new frmMain(dtbl.Rows[0]["Role"].ToString());
                    this.Hide();
                    objFrmMain.Show();
                }*/
                /*
                if (dtbl.Rows[0]["username"].ToString() == "user1")
                {
                    //MessageBox.Show("Madela you didiit, glory be to the most high god, Jehova");
                    //frmMain objFrmMain = new frmMain("Hello World");
                    frmMain objFrmMain = new frmMain(dtbl.Rows[0]["username"].ToString());
                    this.Hide();
                    objFrmMain.Show();
                }
                else if (dtbl.Rows[0]["username"].ToString() == "user2")
                {
                    // MessageBox.Show("User 2 , glory be to the most high god, Jehova");
                    frmMain objFrmMain = new frmMain(dtbl.Rows[0]["username"].ToString());
                    this.Hide();
                    objFrmMain.Show();
                } */

             

            }
            else
            {
                MessageBox.Show("This user doesnt exist in our records, Please check you login details");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
